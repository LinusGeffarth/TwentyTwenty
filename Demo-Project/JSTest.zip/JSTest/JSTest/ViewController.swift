//
//  ViewController.swift
//  JSTest
//
//  Created by Linus Geffarth on 17.06.16.
//  Copyright © 2016 creativeSOG. All rights reserved.
//

import UIKit
import JavaScriptCore

class ViewController: UIViewController {

    @IBOutlet weak var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        var html: NSString = ""
        let htmlFile = NSURL(fileURLWithPath:NSBundle.mainBundle().pathForResource("index", ofType:"html")!)
        do {
            html = try NSString(contentsOfURL: htmlFile, encoding: NSUTF8StringEncoding)
        } catch {}
        webView.loadHTMLString(html as String, baseURL: htmlFile)
    }
}